# Imports necesarios
import numpy as np
import pandas as pd
import seaborn as sb
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
plt.rcParams['figure.figsize'] = (16, 9)
plt.style.use('ggplot')
from sklearn import linear_model
from sklearn.metrics import mean_squared_error, r2_score

# Cargamos los datos de entrada
data = pd.read_csv("articulos_ml.csv")

# Veamos cuantas dimensiones y registros contiene
print("Dimensiones del dataset:", data.shape)

# Veamos esas primeras filas
print("\nPrimeras filas del dataset:")
print(data.head())

#Visualizar estadisiticas

print("\nEstadisticas del dataset:")
print(data.describe())

# Para mostrar gráficos, añade plt.show() al final de cada visualización
data.drop(['Title', 'url'], axis=1).hist()
plt.show()


