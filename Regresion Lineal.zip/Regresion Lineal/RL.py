# Importar bibliotecas necesarias
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Cargar datos desde el archivo CSV
data = pd.read_csv("articulos_ml.csv")

# Filtrar los datos: solo tomamos artículos con hasta 3500 palabras y hasta 80k shares
filtered_data = data[(data['Word count'] <= 3500) & (data['# Shares'] <= 80000)]

# Preparar datos para la regresión
X = filtered_data[['Word count']]  # Variable independiente: número de palabras
y = filtered_data['# Shares']      # Variable dependiente: número de shares

# Crear y entrenar el modelo de regresión lineal
model = LinearRegression()
model.fit(X, y)

# Realizar predicciones
y_pred = model.predict(X)

# Mostrar resultados del modelo
print('Pendiente:', model.coef_[0])
print('Intercepto:', model.intercept_)
print('Error cuadrático medio:', mean_squared_error(y, y_pred))
print('Puntaje R²:', r2_score(y, y_pred))

# Graficar los resultados
plt.scatter(X, y, color='blue', label='Datos reales')
plt.plot(X, y_pred, color='red', label='Regresión lineal')
plt.title('Regresión Lineal: Palabras vs Shares')
plt.xlabel('Número de palabras')
plt.ylabel('Número de shares')
plt.legend()
plt.show()

# Hacer una predicción específica
palabras_test = 2000
shares_predicho = model.predict([[palabras_test]])
print(f'\nPara {palabras_test} palabras, se esperan {int(shares_predicho[0])} shares.')