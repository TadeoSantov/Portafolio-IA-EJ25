"""
Clasificación de Sistemas Operativos usando Regresión Logística Multinomial
Análisis del comportamiento de usuarios para predecir su sistema operativo
"""

# Importación de bibliotecas necesarias
import pandas as pd
import numpy as np
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# Configuración del estilo para visualizaciones
plt.style.use('seaborn-v0_8')
sns.set_theme()
plt.rcParams['figure.figsize'] = (10, 6)
plt.rcParams['font.size'] = 12

# Lectura del archivo CSV
df = pd.read_csv('usuarios_win_mac_lin.csv')

# Mostrar información estadística básica del conjunto de datos
print("\nDescripción Estadística del Dataset:")
print(df.describe())

# Mostrar información sobre tipos de datos y conteos
print("\nInformación del Dataset:")
print(df.info())

# Mostrar distribución de clases
print("\nDistribución de Sistemas Operativos (0=Windows, 1=Mac, 2=Linux):")
class_dist = df.groupby('clase').size()
print(class_dist)

# Visualizar distribución de clases
plt.figure(figsize=(8, 6))
class_dist.plot(kind='bar')
plt.title('Distribución de Sistemas Operativos')
plt.xlabel('Sistema Operativo (0=Windows, 1=Mac, 2=Linux)')
plt.ylabel('Cantidad')
plt.xticks(rotation=0)
plt.show()

# Crear histogramas para todas las características
plt.figure(figsize=(12, 8))
df.drop(['clase'], axis=1).hist()
plt.suptitle('Histogramas de Características')
plt.tight_layout()
plt.show()

# Crear gráfico de relaciones entre características
plt.figure(figsize=(12, 12))
sns.pairplot(df, 
             hue='clase', 
             vars=['duracion', 'paginas', 'acciones', 'valor'],
             kind='reg',
             height=2.5)
plt.suptitle('Relaciones entre Características por Sistema Operativo', y=1.02)
plt.show()

# Preparación de datos
X = df[['duracion', 'paginas', 'acciones', 'valor']]
y = df['clase']

# División en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Creación y entrenamiento del modelo
modelo = linear_model.LogisticRegression(multi_class='multinomial', max_iter=1000)
modelo.fit(X_train, y_train)

# Realizar predicciones
y_pred = modelo.predict(X_test)

# Imprimir métricas de evaluación del modelo
print("\nPrecisión del modelo:", accuracy_score(y_test, y_pred))
print("\nInforme de Clasificación:")
print(classification_report(y_test, y_pred, 
                          target_names=['Windows', 'Mac', 'Linux']))
print("\nMatriz de Confusión:")
print(confusion_matrix(y_test, y_pred))

# Visualización de la matriz de confusión
plt.figure(figsize=(10, 8))
sns.heatmap(confusion_matrix(y_test, y_pred), 
            annot=True, 
            fmt='d',
            cmap='Blues')
plt.title('Matriz de Confusión')
plt.xlabel('Predicción')
plt.ylabel('Valor Real')
plt.show()

# Visualización de la importancia de características
importancia_caracteristicas = pd.DataFrame({
    'caracteristica': X.columns,
    'importancia': abs(modelo.coef_[0])
})
importancia_caracteristicas = importancia_caracteristicas.sort_values('importancia', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='importancia', y='caracteristica', data=importancia_caracteristicas)
plt.title('Importancia de Características')
plt.xlabel('Importancia')
plt.ylabel('Característica')
plt.show()

print("\n=== Análisis Completado ===")