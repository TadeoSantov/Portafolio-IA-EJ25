import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

from imblearn.under_sampling import NearMiss
from collections import Counter

# Define LABELS
LABELS = ['Normal', 'Fraude']

# Cargar el archivo CSV
try:
    df = pd.read_csv("creditcard.csv")  # Asegúrate de que el archivo esté en el mismo directorio
except FileNotFoundError:
    print("Error: El archivo 'creditcard.csv' no se encuentra en el directorio.")
    exit()

# Verificar si la columna 'Class' existe
if 'Class' not in df.columns:
    print("Error: La columna 'Class' no existe en el archivo CSV.")
    exit()

# Mostrar las primeras 5 filas
print(df.head(n=5))

# Mostrar la forma del DataFrame
print("Forma del DataFrame:", df.shape)

# Contar las clases
print("Distribución de clases:")
print(pd.value_counts(df['Class'], sort=True))

# Graficar la distribución de clases
count_classes = pd.value_counts(df['Class'], sort=True)
count_classes.plot(kind='bar', rot=0)
plt.xticks(range(2), LABELS)
plt.title("Frequency by observation number")
plt.xlabel("Class")
plt.ylabel("Number of Observations")
plt.tight_layout()
plt.show()

# Definir etiquetas y características
y = df['Class']
X = df.drop('Class', axis=1)

# Dividir en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.7, random_state=42)

# Crear una función para entrenar el modelo
def run_model(X_train, X_test, y_train, y_test):
    clf_base = LogisticRegression(C=1.0, penalty='l2', random_state=1, solver="newton-cg")
    clf_base.fit(X_train, y_train)
    return clf_base

# Función para mostrar los resultados
def mostrar_resultados(y_test, pred_y):
    conf_matrix = confusion_matrix(y_test, pred_y)
    plt.figure(figsize=(12, 12))
    sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, fmt="d", cmap="Blues")
    plt.title("Confusion matrix")
    plt.ylabel('True class')
    plt.xlabel('Predicted class')
    plt.tight_layout()
    plt.show()
    print("Reporte de clasificación:")
    print(classification_report(y_test, pred_y))

# Entrenar el modelo inicial
model = run_model(X_train, X_test, y_train, y_test)
pred_y = model.predict(X_test)
mostrar_resultados(y_test, pred_y)

# Aplicar NearMiss para balancear las clases
us = NearMiss(sampling_strategy=0.5, n_neighbors=3, version=2)
X_train_res, y_train_res = us.fit_resample(X_train, y_train)

print("Distribución antes del remuestreo:", Counter(y_train))
print("Distribución después del remuestreo:", Counter(y_train_res))

# Entrenar el modelo con datos balanceados
model = run_model(X_train_res, X_test, y_train_res, y_test)
pred_y = model.predict(X_test)
mostrar_resultados(y_test, pred_y)