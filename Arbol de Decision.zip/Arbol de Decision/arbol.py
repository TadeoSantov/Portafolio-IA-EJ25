# Imports necesarios
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold, cross_val_score
from sklearn.preprocessing import LabelEncoder
import subprocess
from PIL import Image as PImage
import os

# Configuración general
plt.rcParams['figure.figsize'] = (16, 9)
plt.style.use('ggplot')

# Cargar los datos
artists_billboard = pd.read_csv(r"artists_billboard_fix3.csv")

# Verificar las dimensiones del dataset
print(f"Dimensiones del dataset: {artists_billboard.shape}")

# Mostrar las primeras filas del dataset
print("\nPrimeras filas del dataset:")
print(artists_billboard.head())

# Mostrar información sobre el dataset
print("\nInformación del dataset:")
artists_billboard.info()

# Mostrar estadísticas descriptivas
print("\nEstadísticas descriptivas:")
print(artists_billboard.describe())

# Verificar valores faltantes
print("\nValores faltantes por columna:")
print(artists_billboard.isnull().sum())

# Identificar la variable objetivo
if 'top' in artists_billboard.columns:
    target_column = 'top'
else:
    raise ValueError("No se encontró la columna 'top' como variable objetivo.")

# Visualizar la distribución de la variable objetivo
plt.figure(figsize=(8, 6))
sns.countplot(x=target_column, data=artists_billboard)
plt.title(f'Distribución de {target_column}')
plt.xlabel('Clase')
plt.ylabel('Frecuencia')
plt.savefig('distribucion_target.png')
plt.close()

# Codificar columnas categóricas
categorical_columns = ['title', 'mood', 'tempo', 'genre', 'artist_type']
le = LabelEncoder()
for col in categorical_columns:
    artists_billboard[col] = le.fit_transform(artists_billboard[col])

# Preparar los datos para el modelo
non_feature_cols = ['id', 'artist', 'chart_date']  # Columnas no relevantes
feature_cols = [col for col in artists_billboard.columns if col not in non_feature_cols + [target_column]]

X = artists_billboard[feature_cols]
y = artists_billboard[target_column]

print(f"\nCaracterísticas utilizadas para el modelo: {feature_cols}")

# Validación cruzada y búsqueda del mejor árbol
cv = KFold(n_splits=10, shuffle=True, random_state=42)
accuracies = []
depth_range = range(1, len(feature_cols) + 1)

for depth in depth_range:
    fold_accuracy = []
    tree_model = tree.DecisionTreeClassifier(
        criterion='entropy',
        min_samples_split=20,
        min_samples_leaf=5,
        max_depth=depth,
        class_weight={1: 3.5}
    )
    for train_fold, valid_fold in cv.split(X):
        f_train = X.iloc[train_fold]
        f_valid = X.iloc[valid_fold]
        y_train = y.iloc[train_fold]
        y_valid = y.iloc[valid_fold]

        model = tree_model.fit(X=f_train, y=y_train)
        valid_acc = model.score(X=f_valid, y=y_valid)
        fold_accuracy.append(valid_acc)

    avg = sum(fold_accuracy) / len(fold_accuracy)
    accuracies.append(avg)

# Mostrar los resultados obtenidos
df = pd.DataFrame({"Max Depth": depth_range, "Average Accuracy": accuracies})
print("\nResultados de la búsqueda del mejor árbol:")
print(df.to_string(index=False))

# Visualizar los resultados
plt.figure(figsize=(10, 6))
sns.lineplot(x="Max Depth", y="Average Accuracy", data=df, marker="o")
plt.title("Precisión promedio vs Profundidad máxima del árbol")
plt.xlabel("Profundidad máxima del árbol")
plt.ylabel("Precisión promedio")
plt.grid()
plt.savefig('busqueda_mejor_arbol.png')
plt.close()

# Entrenar el árbol de decisión con la mejor profundidad
best_depth = df.loc[df['Average Accuracy'].idxmax(), 'Max Depth']
print(f"\nLa mejor profundidad encontrada es: {best_depth}")

final_tree_model = tree.DecisionTreeClassifier(
    criterion='entropy',
    min_samples_split=20,
    min_samples_leaf=5,
    max_depth=int(best_depth),
    class_weight={1: 3.5}
)
final_tree_model.fit(X, y)

# Exportar el árbol de decisión a un archivo DOT
final_dot_file = 'final_tree.dot'
tree.export_graphviz(
    final_tree_model,
    out_file=final_dot_file,
    feature_names=feature_cols,
    class_names=[str(c) for c in final_tree_model.classes_],
    filled=True,
    rounded=True
)

# Convertir el archivo DOT a PNG
try:
    subprocess.run(['dot', '-Tpng', final_dot_file, '-o', 'final_arbol_decision.png'], check=True)
    print("\nÁrbol de decisión final guardado como 'final_arbol_decision.png'")
except FileNotFoundError:
    print("\nError: Graphviz no está instalado o no está en el PATH.")

# Visualizar la importancia de las características
final_feature_importance = pd.DataFrame({
    'feature': feature_cols,
    'importance': final_tree_model.feature_importances_
}).sort_values('importance', ascending=False)

print("\nImportancia de las características del árbol final:")
print(final_feature_importance)

plt.figure(figsize=(10, 8))
sns.barplot(x='importance', y='feature', data=final_feature_importance)
plt.title('Importancia de las Características (Árbol Final)')
plt.tight_layout()
plt.savefig('final_importancia_caracteristicas.png')
plt.close()

print("\n¡Análisis completado!")