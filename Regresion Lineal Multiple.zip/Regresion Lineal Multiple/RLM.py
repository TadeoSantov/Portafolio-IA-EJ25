# Importar bibliotecas necesarias
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from mpl_toolkits.mplot3d import Axes3D

# Cargar datos desde el archivo CSV
data = pd.read_csv("articulos_ml.csv")

# Filtrar los datos: solo tomamos artículos con hasta 3500 palabras y hasta 80k shares
filtered_data = data[(data['Word count'] <= 3500) & (data['# Shares'] <= 80000)]

# Llenar valores NaN con 0
filtered_data['# of comments'] = filtered_data['# of comments'].fillna(0)
filtered_data['# Images video'] = filtered_data['# Images video'].fillna(0)
filtered_data['# of Links'] = filtered_data['# of Links'].fillna(0)

# Crear variable combinada (suma de enlaces, comentarios e imágenes)
suma = filtered_data["# of Links"] + filtered_data['# of comments'] + filtered_data['# Images video']

# Crear matriz de características
dataX2 = pd.DataFrame()
dataX2["Word count"] = filtered_data["Word count"]
dataX2["suma"] = suma

# Convertir a arrays de numpy
XY_train = np.array(dataX2)
z_train = filtered_data['# Shares'].values

# Crear y entrenar el modelo de regresión lineal múltiple
regr2 = LinearRegression()
regr2.fit(XY_train, z_train)

# Realizar predicciones
z_pred = regr2.predict(XY_train)

# Mostrar resultados del modelo
print('Coeficientes:', regr2.coef_)
print("Error cuadrático medio: %.2f" % mean_squared_error(z_train, z_pred))
print('Puntaje de varianza: %.2f' % r2_score(z_train, z_pred))


# Creamos una malla, sobre la cual gra# ...existing code...

# Crear visualización 3D
fig = plt.figure(figsize=(12, 8))  # Aumentar tamaño de la figura
ax = fig.add_subplot(111, projection='3d')  # Usar add_subplot en lugar de Axes3D

# Creamos una malla, sobre la cual graficaremos el plano
# Usar rangos basados en los datos reales
x_min, x_max = XY_train[:, 0].min(), XY_train[:, 0].max()
y_min, y_max = XY_train[:, 1].min(), XY_train[:, 1].max()
xx, yy = np.meshgrid(np.linspace(x_min, x_max, num=20), 
                     np.linspace(y_min, y_max, num=20))

# Calculamos los valores del plano para los puntos x e y
nuevoX = (regr2.coef_[0] * xx)
nuevoY = (regr2.coef_[1] * yy)

# Calculamos los correspondientes valores para z
z = (nuevoX + nuevoY + regr2.intercept_)

# Graficamos el plano con mayor transparencia y color más visible
surf = ax.plot_surface(xx, yy, z, alpha=0.3, cmap='viridis')

# Graficamos en azul los puntos en 3D con mayor tamaño y transparencia
ax.scatter(XY_train[:, 0], XY_train[:, 1], z_train, 
          c='blue', s=50, alpha=0.6, label='Datos reales')

# Graficamos en rojo los puntos predichos
ax.scatter(XY_train[:, 0], XY_train[:, 1], z_pred, 
          c='red', s=50, alpha=0.4, label='Predicciones')

# Ajustamos la vista de la cámara para mejor visualización
ax.view_init(elev=20., azim=45)

# Configuramos las etiquetas y título con mejor formato
ax.set_xlabel('Cantidad de Palabras', labelpad=10)
ax.set_ylabel('Enlaces + Comentarios\n+ Imágenes', labelpad=10)
ax.set_zlabel('Shares', labelpad=10)
ax.set_title('Regresión Lineal con Múltiples Variables', pad=20)

# Agregar leyenda
ax.legend()

# Agregar barra de color
fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)


# Hacer una predicción específica
xx, yy = np.meshgrid(np.linspace(0, 3500, num=10), np.linspace(0, 60, num=10))

# Calculamos los valores del plano para los puntos x e y
nuevoX = (regr2.coef_[0] * xx)
nuevoY = (regr2.coef_[1] * yy)

# Calculamos los correspondientes valores para z
z = (nuevoX + nuevoY + regr2.intercept_)

# Graficamos el plano
ax.plot_surface(xx, yy, z, alpha=0.2, cmap='hot')

# Graficamos en azul los puntos en 3D
ax.scatter(XY_train[:, 0], XY_train[:, 1], z_train, c='blue', s=30)

# Graficamos en rojo, los puntos predichos
ax.scatter(XY_train[:, 0], XY_train[:, 1], z_pred, c='red', s=40)

# Ajustamos la vista de la cámara
ax.view_init(elev=30., azim=65)

# Configuramos las etiquetas y título
ax.set_xlabel('Cantidad de Palabras')
ax.set_ylabel('Cantidad de Enlaces,\nComentarios e Imagenes')
ax.set_zlabel('Compartido en Redes')
ax.set_title('Regresión Lineal con Múltiples Variables')

plt.show()

# Predicción para un caso específico
# Artículo con 2000 palabras, 10 enlaces, 4 comentarios y 6 imágenes
caracteristicas_combinadas = 10 + 4 + 6  # suma de enlaces, comentarios e imágenes
z_Dosmil = regr2.predict([[2000, caracteristicas_combinadas]])
print("\nPredicción para un artículo con:")
print("- 2000 palabras")
print("- 10 enlaces")
print("- 4 comentarios")
print("- 6 imágenes")
print(f"Número de shares esperados: {int(z_Dosmil[0])}")